public abstract class ConstType extends NumericType {

}
