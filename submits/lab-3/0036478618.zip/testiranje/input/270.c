int main(void){
int x;



return 0;
}