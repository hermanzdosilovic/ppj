int main(void)
{
  printf();
}