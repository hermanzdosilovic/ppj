int a = 100;
char b[2147483648];

int main(void) {
  return 0;
}