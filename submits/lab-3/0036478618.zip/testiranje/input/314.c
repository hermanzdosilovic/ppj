int main(void){
 int y=90;
 //char a[1024]="asd";
 char b='d';

 int c[10]={0,2,3};
char a[4]="\\\\";

 y=b;
 return 0;
 }