int a = b = c = d = f = g = 1;
