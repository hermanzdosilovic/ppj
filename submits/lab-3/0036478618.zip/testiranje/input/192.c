int f(void)
{
  return x;
}
int main(void)
{
  int x;
  f();
  return 0;
}