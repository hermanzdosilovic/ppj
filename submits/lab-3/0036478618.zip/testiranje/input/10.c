int main(void) {
  char c;
  c = '\t';
  return 0;
}
