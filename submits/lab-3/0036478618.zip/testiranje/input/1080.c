void v(void);
int main(int a, int b){
char h;
void v(void);
//int g[10]=h;
main(3,4);
v();

return 0;
}

int v(void ){

return 3;
}