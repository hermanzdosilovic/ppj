void p(void);

int main (int a){
//int p(vosid);
int c[12];
a=(const char)c[1233];
return a;
}

void p (void){

return;}