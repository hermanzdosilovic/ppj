int main(void){

int z;
char z;

return 0;
}