int x;
int main(void){

char x==0;

return 0;
}