const int r=33;

void f(void){
return;
}
int main(void) {
int a = 666;
const char e='e';
char t;
int s=3;
{
int a = 5;
int y = e + 1; // 6
const int v=666;

t= v;

s = y + 1; // 7
}
s = a + 1; // 4
return 0;
}