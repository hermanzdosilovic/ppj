int main(void) {
  int a[10];
  int a[1][2];
  return 0;
}
