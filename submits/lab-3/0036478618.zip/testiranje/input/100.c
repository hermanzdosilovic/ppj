char f(void)
{return 'f';}
int main(void)
{
return f();
}
