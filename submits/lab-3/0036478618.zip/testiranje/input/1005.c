int a,b,c;

a = "sdlkjfhksjdf";