int x = 4294967296;

int main(void) {
  return 0;
}