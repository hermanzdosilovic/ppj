int y = 3;

void x(void) {
    if (1)
        ;
    else if (2)
        y = 12;
    else
        y = 0;;
}