int z;
int main(void){
z=5;

return 0;
}