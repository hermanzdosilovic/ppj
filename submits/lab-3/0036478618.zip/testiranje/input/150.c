int f(int x);
int main(void)
{ 
  return f(1);
}
int f(int x)
{
  f(x);
}