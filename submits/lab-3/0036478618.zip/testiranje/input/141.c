int main(void)
{
  printf("a");
}