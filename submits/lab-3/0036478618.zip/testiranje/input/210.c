char a[2]={'\\','c'};
int main(void)
{
  return a[0]+'d';
}