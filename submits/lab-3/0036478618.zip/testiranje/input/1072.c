int main(void) {
  int f(int a, int b, int b);
  return 0;
}
