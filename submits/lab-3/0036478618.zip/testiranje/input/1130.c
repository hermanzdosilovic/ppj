int main(void) {
  char a[10] = {'a','b','c','\0'};
  return 0;
 }