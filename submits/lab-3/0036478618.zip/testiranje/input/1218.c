int main (int a){
 a++;
return a;
}