int main(void) {
  int a = 0;
  int b = a;
  return 0;
}
