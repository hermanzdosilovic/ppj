int main(void){
char c[123]="\w";
return 0;
}