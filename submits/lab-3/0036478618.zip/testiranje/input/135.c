int main(void)
{  
int a=2;
 if (a) 
 {
 a=a*+1/(0+-a);
 }else
 return 0;
 }
