int main(void)
{  
int a=2;
 if (a) else
 return 0;
 }
