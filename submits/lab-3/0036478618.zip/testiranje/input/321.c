
int main (void)
{
  int a;
  return b+2;
}

