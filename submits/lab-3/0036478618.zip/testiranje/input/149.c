
int main(void)
{
  return 'c'/9;
}