
int i;
void main (void){
  if(1){
int i;
for(i=0;i<2;i++){
  i=3;
{
int i=4;
{{{{
int i=3;
{
i++;}
}}}}
}
}

return ;}
}