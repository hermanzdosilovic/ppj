 int main(void) {
if(1){
continue;
}
 return 0;
 }