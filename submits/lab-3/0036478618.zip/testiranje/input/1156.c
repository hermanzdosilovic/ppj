int main(void) {
 char a[10] = {'\\\\','3','4'};
 return 0;
}


