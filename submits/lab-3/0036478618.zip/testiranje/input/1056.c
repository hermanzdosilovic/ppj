int a[2]={2};
char b[3]="x\"\x";
int main(int a)
{
return a;
}