// komentar

int a[102] = "\\\\";

int main(void) {
  return 0;
}