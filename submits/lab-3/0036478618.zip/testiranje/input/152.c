int a(int a);

int b(int b);

int f(void) {
  int a(int a, int b);
  return 0;
}

int main(void) {
  return 0;
}

int a( int a, int b) {return 5;}
