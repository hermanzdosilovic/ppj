int main(void)
{
  print("a");
}