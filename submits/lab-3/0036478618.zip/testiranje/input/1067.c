int a = 100;
char b = (char) 256;

int main(void) {
  return 0;
}