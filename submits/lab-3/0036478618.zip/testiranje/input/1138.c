int main(void) {
  int j;
while (j) {
    break;
    break;
   }

  
  return 0;
}