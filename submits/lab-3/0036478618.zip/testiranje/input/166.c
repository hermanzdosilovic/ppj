int main(void){
const int b=3;
b--;  
}
