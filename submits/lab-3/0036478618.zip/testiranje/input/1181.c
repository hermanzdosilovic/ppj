int main(void){
  char a[12]="dadada";
  int g[122]="dsad";
  const int v=2;

  int b=2;
int ad[123];


//v=44;
  a[0]=(char)b;
  v=b;
  return 0;
}