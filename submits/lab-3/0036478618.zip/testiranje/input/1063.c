int main(int a, int b){
char h;
int v(void);
//int g[10]=h;
main(3,4);
h=(const char)v();

return 0;
}

void v(void ){

return;
}