int b,c,d,e,f,g;
int a = b = c = d = f = g = 1;
