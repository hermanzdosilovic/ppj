char a[2] = "\\",. c = 'f';

int main(void) {
  return 0;
}
