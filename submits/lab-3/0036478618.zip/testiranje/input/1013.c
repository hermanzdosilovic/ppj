int a,b,c;

int main(void) {
a = 5;
return 0;
}