char main(int b){
  int a;
{
  int a=4;
  b=5;
}
  return 3;
}