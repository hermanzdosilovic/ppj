int y;
int x;

int zbrajanje(void){
  int x;
  int y;
  return x+y;
}

int main(void){
int z;

return 0;
}