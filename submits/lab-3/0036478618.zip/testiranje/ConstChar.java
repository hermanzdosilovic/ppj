public class ConstChar extends ConstType {

  public static ConstChar CONST_CHAR = new ConstChar();

  private ConstChar() {}

}
