

/**
 * @author Herman Zvonimir Dosilovic
 */
public abstract class Rule {
  private Symbol symbol;

  public Rule(Symbol symbol) {
    this.symbol = symbol;
  }

  public void visit(SNode node, Scope scope) throws SemanticException {
    node.setScope(scope);
    checkRule(node, scope);
  };

  public abstract void checkRule(SNode node, Scope scope) throws SemanticException; 
  
  public Symbol getSymbol() {
    return symbol;
  }
  
  public String getErrorMessage(SNode node) {
    StringBuilder message = new StringBuilder();
    message.append(node.getSymbol());
    message.append(" ::= ");

    for (SNode child : node.getChildren()) {
      if (child.getSymbol() instanceof NonTerminalSymbol) {
        message.append(child.getSymbol());
      } else {
        message.append(child.getSymbol() + "(");
        message.append(child.getLineNumber() + "," + child.getValue() + ")");
      }
      message.append(" ");
    }
 
    return message.toString().trim();
  }
}
