
public class Int extends NumericType implements ReturnType {
  
  public static Int INT = new Int();
  
  private Int() {}
}
