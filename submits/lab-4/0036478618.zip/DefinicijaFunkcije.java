

import java.util.Arrays;
import java.util.List;


/**
 * @author Ivan Trubic
 */
public class DefinicijaFunkcije extends Rule {
  public static DefinicijaFunkcije DEFINICIJA_FUNKCIJE = new DefinicijaFunkcije();

  private DefinicijaFunkcije() {
    super(new NonTerminalSymbol("<definicija_funkcije>"));
  }

  @Override
  public void checkRule(SNode node, Scope scope) throws SemanticException {
    List<String> children = node.getValuesOfChildren();
    
    GeneratorKoda.write("\n" + GeneratorKoda.getFunctionLabel(node.getChildren().get(1).getName()));
    GeneratorKoda.writeln("\tMOVE R7, R6");
    if (children.equals(Arrays.asList("<ime_tipa>", "IDN", "L_ZAGRADA", "KR_VOID", "D_ZAGRADA",
        "<slozena_naredba>"))) {
      SNode ime_tipa = node.getChildren().get(0);
      // 1
      ime_tipa.visit(scope);

      // 2
      if (TypesHelper.isConstT(ime_tipa.getType())) {
        throw new SemanticException(getErrorMessage(node));
      }

      // 3
      SNode idn = node.getChildren().get(1);
      if (scope.hasDefined(idn.getName())) { // this is already in global scope, checked by SA
        throw new SemanticException(getErrorMessage(node));
      }

      // 4
      VoidFunctionType functionType = new VoidFunctionType((ReturnType) ime_tipa.getType());
      // this is already in global scope, checked by SA
      if (scope.hasDeclared(idn.getName()) && !scope.getType(idn.getName()).equals(functionType)) {
        throw new SemanticException(getErrorMessage(node));
      }

      // 5
      scope.insert(idn.getName(), functionType, true);
      // 6
      Scope scopeSlozenaNaredba = new Scope(scope);
      //scopeSlozenaNaredba.insert(idn.getName(), functionType, true);
      node.getChildren().get(5).visit(scopeSlozenaNaredba);

    } else if (children.equals(Arrays.asList("<ime_tipa>", "IDN", "L_ZAGRADA", "<lista_parametara>",
        "D_ZAGRADA", "<slozena_naredba>"))) {
      SNode ime_tipa = node.getChildren().get(0);
      // 1
      ime_tipa.visit(scope);

      // 2
      if (TypesHelper.isConstT(ime_tipa.getType())) {
        throw new SemanticException(getErrorMessage(node));
      }

      // 3
      SNode idn = node.getChildren().get(1);
      if (scope.hasDefined(idn.getName())) {
        throw new SemanticException(getErrorMessage(node));
      }

      // 4
      SNode lista_parametara = node.getChildren().get(3);
      lista_parametara.visit(scope);

      // 5
      NonVoidFunctionType functionType =
          new NonVoidFunctionType(lista_parametara.getTypes(), (ReturnType) ime_tipa.getType());
      if (scope.hasDeclared(idn.getName()) && !scope.getType(idn.getName()).equals(functionType)) {
        throw new SemanticException(getErrorMessage(node));
      }

      // 6
      scope.insert(idn.getName(), functionType, true);

      // 7
      Scope scopeSlozenaNaredba = new Scope(scope.getGlobalScope());
      //scopeSlozenaNaredba.insert(idn.getName(), functionType, true);
      int size = lista_parametara.getTypes().size();
      for (int i = 0; i < size; i++) {
        scopeSlozenaNaredba.insert(lista_parametara.getNames().get(i),
            lista_parametara.getTypes().get(i), false);
        scopeSlozenaNaredba.setOffset(lista_parametara.getNames().get(i), 4*(size - i + 1));
      }
      node.getChildren().get(5).visit(scopeSlozenaNaredba);
      if (functionType.getReturnType() instanceof Void) {
        GeneratorKoda.writeln("\tMOVE R6, R7");
        GeneratorKoda.writeln("\tRET");
      }
    }
  }
}
