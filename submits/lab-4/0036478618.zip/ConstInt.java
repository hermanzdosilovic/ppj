
public class ConstInt extends ConstType {
  
  public static ConstInt CONST_INT = new ConstInt();
  
  private ConstInt() {}
  
}
