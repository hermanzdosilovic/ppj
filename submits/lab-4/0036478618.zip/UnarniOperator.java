

/**
 * @author Herman Zvonimir Dosilovic
 */
public class UnarniOperator extends Rule {
  public static UnarniOperator UNARNI_OPERATOR = new UnarniOperator();
  
  private UnarniOperator() {
    super(new NonTerminalSymbol("<unarni_operator>"));
  }
  
  @Override
  public void checkRule(SNode node, Scope scope) throws SemanticException {
    return;
  }
}
