
import java.util.Arrays;
import java.util.List;


/**
 * @author Herman Zvonimir Dosilovic
 */
public class BinIIzraz extends Rule {
  public static BinIIzraz BIN_I_IZRAZ = new BinIIzraz();

  private BinIIzraz() {
    super(new NonTerminalSymbol("<bin_i_izraz>"));
  }

  @Override
  public void checkRule(SNode node, Scope scope) throws SemanticException {
    List<String> children = node.getValuesOfChildren();
    if (children.equals(Arrays.asList("<jednakosni_izraz>"))) {
      SNode jednakosni_izraz = node.getChildren().get(0);
      jednakosni_izraz.visit(scope);
      node.setType(jednakosni_izraz.getType());
      node.setlValue(jednakosni_izraz.islValue());
    } else if (children.equals(Arrays.asList("<bin_i_izraz>", "OP_BIN_I", "<jednakosni_izraz>"))) {
      SNode bin_i_izraz = node.getChildren().get(0);
      SNode jednakosni_izraz = node.getChildren().get(2);

      bin_i_izraz.visit(scope);
      if (!TypesHelper.canImplicitlyCast(bin_i_izraz.getType(), Int.INT)) {
        throw new SemanticException(getErrorMessage(node));
      }
      jednakosni_izraz.visit(scope);
      if (!TypesHelper.canImplicitlyCast(jednakosni_izraz.getType(), Int.INT)) {
        throw new SemanticException(getErrorMessage(node));
      }

      GeneratorKoda.writeln("\tPOP R1");
      if (jednakosni_izraz.islValue()) {
        GeneratorKoda.writeln("\tLOAD R1, (R1)");
      }
      GeneratorKoda.writeln("\tPOP R0");
      if (bin_i_izraz.islValue()) {
        GeneratorKoda.writeln("\tLOAD R0, (R0)");
      }


      GeneratorKoda.writeln("\tAND R0, R1, R0");
      GeneratorKoda.writeln("\tPUSH R0");

      node.setType(Int.INT);
      node.setlValue(false);
    }
  }
}
