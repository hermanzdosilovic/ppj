

public class ListaNaredbi extends Rule {

  public static ListaNaredbi LISTA_NAREDBI = new ListaNaredbi();

  private ListaNaredbi() {
    super(new NonTerminalSymbol("<lista_naredbi>"));
  }

  @Override
  public void checkRule(SNode node, Scope scope) throws SemanticException {
    for (SNode child : node.getChildren()) {
      child.visit(scope);
    }
  }

}
