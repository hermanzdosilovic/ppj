
public class Void implements ReturnType {

  public static Void VOID = new Void();
  
  private Void() {}
  
}
