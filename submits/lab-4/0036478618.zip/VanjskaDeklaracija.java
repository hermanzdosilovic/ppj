

/**
 * @author Ivan Trubic
 */
public class VanjskaDeklaracija extends Rule {
  public static VanjskaDeklaracija VANJSKA_DEKLARACIJA = new VanjskaDeklaracija();

  private VanjskaDeklaracija() {
    super(new NonTerminalSymbol("<vanjska_deklaracija>"));
  }

  @Override
  public void checkRule(SNode node, Scope scope) throws SemanticException {
    for (SNode child : node.getChildren()) {
      child.visit(scope);
    }
  }
}
