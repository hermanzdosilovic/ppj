
public class Char extends NumericType implements ReturnType {

  public static Char CHAR = new Char();
  
  private Char() {}
}
