import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;


public class TypesHelper {

  private static Map<NumericType, List<NumericType>> transitions = new HashMap<>();

  static {
    transitions.put(ConstInt.CONST_INT, Arrays.asList((NumericType)Int.INT));
    transitions.put(ConstChar.CONST_CHAR, Arrays.asList((NumericType)Char.CHAR));
    transitions.put(Int.INT, Arrays.asList((NumericType)ConstInt.CONST_INT));
    transitions.put(Char.CHAR, Arrays.asList((NumericType)ConstChar.CONST_CHAR, Int.INT));
  }

  public static boolean canImplicitlyCast(Type source, Type target) {
    if (source instanceof NumericType && target instanceof NumericType) {
      return canImplicitlyCast((NumericType)source, (NumericType)target);
    }
    if (source instanceof Array && target instanceof Array) {
      return canImplicitlyCast((Array) source, (Array) target);
    }
    return false;
  }

  public static boolean canImplicitlyCast(NumericType source, NumericType target) {
    if (source == null || target == null) {
      return false;
    }

    if (source == target) {
      return true;
    }

    Queue<Type> q = new LinkedList<>();
    Set<Type> visited = new HashSet<>();
    q.add(source);
    while(!q.isEmpty()) {
      Type current = q.remove();
      if (transitions.containsKey(current)) {
        for(Type next : transitions.get(current)) {
          if (!visited.contains(next)) {
            if (next == target) {
              return true;
            }
            visited.add(next);
            q.add(next);
          }
        }
      }
    }
    return false;
  }

  public static boolean canImplicitlyCast(Array source, Array target) {
    if (source == null || target == null)
      return false;
    return
        source.getNumericType() == target.getNumericType()
     || !isConstT((Type)source.getNumericType()) && constT((Type)source.getNumericType()) == target.getNumericType();
  }

  public static boolean canExplicitlyCast(Type source, Type target) {
    return isX(source) && isX(target);
  }

  public static ConstType constT(Type type) {
    if (isConstT(type)) {
      return (ConstType) type;
    }
    if (type == Char.CHAR) {
      return ConstChar.CONST_CHAR;
    }
    if (type == Int.INT) {
      return ConstInt.CONST_INT;
    }
    return null;
  }

  public static boolean isLType(Type type) {
    return type == Char.CHAR || type == Int.INT;
  }

  public static boolean isArray(Type type) {
    return type instanceof Array;
  }

  public static boolean isArrayConstT(Type type) {
    if (type instanceof Array) {
      return isConstT(((Array) type).getNumericType());
    }
    return false;
  }

  public static boolean isX(Type type) {
    return type instanceof NumericType;
  }

  public static boolean isT(Type type) {
    return type == Char.CHAR || type == Int.INT;
  }

  public static boolean isConstT(Type type) {
    return type instanceof ConstType;
  }

  public static boolean isFunction(Type type) {
    return type instanceof FunctionType;
  }

  public static boolean isVoidFunction(Type type) {
    return type instanceof VoidFunctionType;
  }

  public static boolean isNonVoidFunction(Type type) {
    return type instanceof NonVoidFunctionType;
  }

  public static Type getTFromX(NumericType type) {
    if (type == ConstChar.CONST_CHAR) {
      return Char.CHAR;
    }
    if (type == ConstInt.CONST_INT) {
      return Int.INT;
    }
    return type;
  }
}
