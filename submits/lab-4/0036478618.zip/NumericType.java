
public abstract class NumericType implements Type {
}
