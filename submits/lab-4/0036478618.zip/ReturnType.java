
public interface ReturnType extends Type {
}
