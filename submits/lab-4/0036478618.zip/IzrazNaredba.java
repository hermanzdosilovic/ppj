
import java.util.Arrays;
import java.util.List;


public class IzrazNaredba extends Rule {

  public static IzrazNaredba IZRAZ_NAREDBA = new IzrazNaredba();
  
  private IzrazNaredba() {
    super(new NonTerminalSymbol("<izraz_naredba>"));
  }
  
  @Override
  public void checkRule(SNode node, Scope scope) throws SemanticException {
    List<String> childrenValues = node.getValuesOfChildren();
    if (childrenValues.equals(Arrays.asList("TOCKAZAREZ"))) {
      node.setType(Int.INT); 
    } else if (childrenValues.equals(Arrays.asList("<izraz>", "TOCKAZAREZ"))) {
      node.getChildren().get(0).visit(scope);
      node.setType(node.getChildren().get(0).getType());
    }
  }

}
