
import java.util.Arrays;
import java.util.List;


public class SlozenaNaredba extends Rule {

  public static SlozenaNaredba SLOZENA_NAREDBA = new SlozenaNaredba();

  private SlozenaNaredba() {
    super(new NonTerminalSymbol("<slozena_naredba>"));
  }

  @Override
  public void checkRule(SNode node, Scope scope) throws SemanticException {
    List<String> childrenValues = node.getValuesOfChildren();
    if (childrenValues.equals(Arrays.asList("L_VIT_ZAGRADA", "<lista_naredbi>", "D_VIT_ZAGRADA"))) {
      node.getChildren().get(1).visit(scope);
    } else if (childrenValues.equals(Arrays.asList("L_VIT_ZAGRADA", "<lista_deklaracija>",
        "<lista_naredbi>", "D_VIT_ZAGRADA"))) {
      node.getChildren().get(1).visit(scope);
      node.getChildren().get(2).visit(scope);
    }
  }

}
