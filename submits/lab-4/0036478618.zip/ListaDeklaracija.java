

public class ListaDeklaracija extends Rule {
  public static ListaDeklaracija LISTA_DEKLARACIJA = new ListaDeklaracija();

  private ListaDeklaracija() {
    super(new NonTerminalSymbol("<lista_deklaracija>"));
  }

  @Override
  public void checkRule(SNode node, Scope scope) throws SemanticException {
    for (SNode child : node.getChildren()) {
      child.visit(scope);
    }
  }
}
