
public interface Type {
}
