

/**
 * @author Ivan Trubic
 */
public class PrijevodnaJedinica extends Rule {
  public static PrijevodnaJedinica PRIJEVODNA_JEDINICA = new PrijevodnaJedinica();

  private PrijevodnaJedinica() {
    super(new NonTerminalSymbol("<prijevodna_jedinica>"));
  }

  @Override
  public void checkRule(SNode node, Scope scope) throws SemanticException {
    for (SNode child : node.getChildren()) {
      child.visit(scope);
    }
  }
}
