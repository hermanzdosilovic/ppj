
import java.util.Arrays;
import java.util.List;


public class IzravniDeklarator extends Rule {
  public static IzravniDeklarator IZRAVNI_DEKLARATOR = new IzravniDeklarator();

  private IzravniDeklarator() {
    super(new NonTerminalSymbol("<izravni_deklarator>"));
  }

  @Override
  public void checkRule(SNode node, Scope scope) throws SemanticException {
    List<String> children = node.getValuesOfChildren();

    if (children.equals(Arrays.asList("IDN"))) {
      SNode idn = node.getChildren().get(0);

      // 1
      if (node.getnType().equals(Void.VOID)) {
        throw new SemanticException(getErrorMessage(node));
      }

      // 2
      if (scope.hasDeclared(idn.getName())) {
        throw new SemanticException(getErrorMessage(node));
      }

      // 3
      scope.insert(idn.getName(), node.getnType(), true);
      node.setType(node.getnType());

      SNode parent = node.getParent();
      if (parent.getValuesOfChildren().equals(Arrays.asList("<izravni_deklarator>"))) {
        GeneratorKoda.writeln("\tPUSH R0\t; declaration"); // trash for declaration;
      }
      
      int lastOffset = scope.lastOffset();
      scope.setOffset(idn.getName(), lastOffset - 4);
    } else if (children.equals(Arrays.asList("IDN", "L_UGL_ZAGRADA", "BROJ", "D_UGL_ZAGRADA"))) {

      // 1
      if (node.getnType().equals(Void.VOID)) {
        throw new SemanticException(getErrorMessage(node));
      }

      // 2
      SNode idn = node.getChildren().get(0);
      if (scope.hasDeclared(idn.getName())) {
        throw new SemanticException(getErrorMessage(node));
      }

      // 3
      Integer brojValue = null;
      try {
        brojValue = Integer.decode(node.getChildren().get(2).getValue());
      } catch (NumberFormatException e) {
        throw new SemanticException(getErrorMessage(node));
      }
      if (brojValue > 1024 || brojValue <= 0) {
        throw new SemanticException(getErrorMessage(node));
      }

      node.setType(new Array((NumericType) node.getnType()));
      // 4
      scope.insert(idn.getName(), node.getType(), true);

      node.setElemCount(brojValue);
      
      SNode parent = node.getParent();
      if (parent.getValuesOfChildren().equals(Arrays.asList("<izravni_deklarator>"))) {
        for (int i = 0; i < brojValue; i++) {
          GeneratorKoda.writeln("\tPUSH R0\t; declaration"); // trash for declaration;
        }
        GeneratorKoda.writeln("\tADD R7, %D " + 4*(brojValue - 1) + ", R0");
        GeneratorKoda.writeln("\tPUSH R0");
      }
      
      int lastOffset = scope.lastOffset();
      scope.setOffset(idn.getName(), lastOffset - 4*brojValue - 4);
    } else if (children.equals(Arrays.asList("IDN", "L_ZAGRADA", "KR_VOID", "D_ZAGRADA"))) {

      // 1
      SNode idn = node.getChildren().get(0);
      VoidFunctionType functionType = new VoidFunctionType((ReturnType) node.getnType());

      if (scope.hasDeclared(idn.getName())) {
        if (!scope.getType(idn.getName()).equals(functionType)) {
          throw new SemanticException(getErrorMessage(node));
        }
      } else {
        scope.insert(idn.getName(), functionType, false);
      }
      node.setType(functionType);
    } else if (children
        .equals(Arrays.asList("IDN", "L_ZAGRADA", "<lista_parametara>", "D_ZAGRADA"))) {
      SNode lista_parametara = node.getChildren().get(2);

      // 1
      lista_parametara.visit(scope);

      // 2
      SNode idn = node.getChildren().get(0);
      NonVoidFunctionType functionType =
          new NonVoidFunctionType(lista_parametara.getTypes(), (ReturnType) node.getnType());

      if (scope.hasDeclared(idn.getName())) {
        if (!scope.getType(idn.getName()).equals(functionType)) {
          throw new SemanticException(getErrorMessage(node));
        }
      } else {
        scope.insert(idn.getName(), functionType, false);
      }
    }
  }
}
