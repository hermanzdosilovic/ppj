
import java.util.Arrays;


public class Naredba extends Rule {

  public static Naredba NAREDBA = new Naredba();
  
  private Naredba() {
    super(new NonTerminalSymbol("<naredba>"));
  }
  
  @Override
  public void checkRule(SNode node, Scope scope) throws SemanticException {
    if (node.getValuesOfChildren().equals(Arrays.asList("<slozena_naredba>"))) {
      node.getChildren().get(0).visit(new Scope(scope));
    } else {
      node.getChildren().get(0).visit(scope);
    }
  }

}
