import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

public class AutomataState implements Serializable {

  /**
   * 
   */
  private static final long serialVersionUID = -2447262554193787065L;
  private int state;
  private Set<LRItem> items = new HashSet<>();
  
  public AutomataState(int state, Set<LRItem> items) {
    this.state = state;
    this.items.addAll(items);
  }
  
  public void addItem(LRItem item) {
    items.add(item);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((items == null) ? 0 : items.hashCode());
    result = prime * result + state;
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    AutomataState other = (AutomataState) obj;
    if (items == null) {
      if (other.items != null)
        return false;
    } else if (!items.equals(other.items))
      return false;
    if (state != other.state)
      return false;
    return true;
  }
  
}
