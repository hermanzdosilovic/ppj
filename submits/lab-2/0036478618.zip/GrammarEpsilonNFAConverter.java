import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author Herman Zvonimir Dosilovic
 */
public class GrammarEpsilonNFAConverter {
  public static Automaton<LRItem, Symbol> convert(Grammar grammar, TerminalSymbol endSymbol) {
    LRItem firstLRState = new LRItem(grammar.getInitialProduction(), 0, Arrays.asList((Symbol) endSymbol));

    TransitionFunction<LRItem, Symbol> transitionFunction = new TransitionFunction<>();

    Set<LRItem> visited = new HashSet<>();
    visited.add(firstLRState);
    buildTransitions(firstLRState, transitionFunction, grammar, visited);

    Set<LRItem> states = new HashSet<>(transitionFunction.getAllSources());
    Set<LRItem> acceptableStates = new HashSet<>(states);

    Set<Symbol> alphabet = new HashSet<>(transitionFunction.getAllInputSymbols());

    return new Automaton<>(states, alphabet, transitionFunction, firstLRState, acceptableStates);
  }

  static void buildTransitions(LRItem item, TransitionFunction<LRItem, Symbol> transitionFunction,
      Grammar grammar, Set<LRItem> visited) {
    if (item.isComplete()) {
      return;
    }

    visited.add(item);
    transitionFunction.addTransition(item, item.getDotSymbol(), item.getNextLRItem());

    if (!visited.contains(item.getNextLRItem())) {
      buildTransitions(item.getNextLRItem(), transitionFunction, grammar, visited);
    }

    if (item.getDotSymbol() instanceof NonTerminalSymbol) {
      NonTerminalSymbol symbol = (NonTerminalSymbol) item.getDotSymbol();
      List<Symbol> nextSymbolSequence = item.getSymbolsAfterDotSymbol();
      Set<Symbol> nextTerminalSymbols = grammar.beginsWith(nextSymbolSequence);
      if (grammar.isEmptySequence(nextSymbolSequence)) {
        nextTerminalSymbols.addAll(item.getTerminalSymbols());
      }
      for (Production production : grammar.getSymbolProductions(symbol)) {
        LRItem nextLRItem = new LRItem(production, 0, new ArrayList<>(nextTerminalSymbols));
        transitionFunction.addEpsilonTransition(item, nextLRItem);
        if (!visited.contains(nextLRItem)) {
          buildTransitions(nextLRItem, transitionFunction, grammar, visited);
        }
      }
    }
  }
}
